import os   #The OS in Python provides for file operations

class Student:                                              
    def __init__(self, id, name, eca, grades, password):    #Initialize the student information attribute
        self.id = id
        self.name = name
        self.eca = eca
        self.grades = grades
        self.password = password


def create_files_if_not_exist(*files):  
    for file in files:                   # Iterate over each file path provided
        if not os.path.exists(file):    # Check if the file doesn't exist
            with open(file, 'w') as f:   # Open the file in write mode
                f.write("")                # Write an empty string to the file

def add_student(users_file, eca_file, grades_file, passwords_file):    
    try:
                                                     # Prompt user for new student information
        id = int(input("Enter new student ID: "))
        name = input("Enter new student name: ")
        eca = input("Enter interested ECA: ")
        grades = [input(f"Enter marks for subject {i + 1}: ") for i in range(5)]
        password = input("Set password: ")

         # Append student information to respective files
        with open(users_file, 'a') as file:
            file.write(f"{id},{name}\n")     # Write ID and name to users_file
        with open(eca_file, 'a') as file:
            file.write(f"{id},{name},{eca}\n")   # Write ID, name, and ECA to eca_file
        with open(grades_file, 'a') as file:        
            file.write(f"{id},{name},{','.join(grades)}\n") # Write ID, name, and grades to grades_file
        with open(passwords_file, 'a') as file:
            file.write(f"{id},{name},{password}\n")     # Write ID, name, and password to passwords_file

        print("Added New Student ..!!..")
    except Exception as e:
        print("Error:", e) # Print exception if errpr occur

def modify_student(users_file, eca_file, grades_file, passwords_file):
    try:
        id = input("Enter ID to modify: ")      # Prompt user for ID to modify
        name = input("Enter new name: ")        # Prompt user for new name
        eca = input("Modify ECA: ")                 # Prompt user to modify ECA
        grades = [input(f"Enter new marks for subject {i + 1}: ") for i in range(5)]     # Prompt user to input new mark
        password = input("Enter new password: ")         # Prompt user to modify password

        def update_file(file, data):
            with open(file, 'r') as f:
                lines = f.readlines()           # Read all lines from the file
            with open(file, 'w') as f:
                for line in lines:
                    parts = line.strip().split(',')      # Split the line into parts
                    if parts[0] == id:
                        f.write(data)            # Write updated data if ID matches
                    else:
                        f.write(line)           # Write the original line if ID doesn't match

        update_file(users_file, f"{id},{name}\n")    # Update user information in users_file
        update_file(eca_file, f"{id},{name},{eca}\n")       # Update ECA information in users_file
        update_file(grades_file, f"{id},{name},{','.join(grades)}\n")       # Update Grades information in users_file
        update_file(passwords_file, f"{id},{name},{password}\n")    # Update password information in users_file

        print("Modification Successful !!")
    except Exception as e:
        print("Error:", e)

def remove_student(users_file, eca_file, grades_file, passwords_file):
    try:
        id = input("Enter student ID to remove: ")  # Prompt user for the student ID to remove
        files = [users_file, eca_file, grades_file, passwords_file]  # List of files to update

        for file in files:
            with open(file, 'r') as f:
                lines = f.readlines()  # Read all lines from the file
            with open(file, 'w') as f:
                for line in lines:
                    if line.split(',')[0] != id:
                        f.write(line)  # Write lines back except for the specified ID

        print("Deleted student data ..!!..")  # Print success message
    except Exception as e:
        print("Error:", e)  # Print error message if an exception occurs

def view_student_data(name, users_file, eca_file, grades_file):
    try:
        id = input("Enter student ID: ")  # Prompt user for the student ID
        found = False  # Flag to track if student data is found

        def print_info(file, callback):
            nonlocal found  # Use nonlocal to modify found variable from outer scope
            with open(file, 'r') as f:
                for line in f:
                    parts = line.strip().split(',')  # Split the line into parts
                    if parts[0] == id and parts[1] == name:  # Check if ID and name match
                        callback(parts)  # Execute callback function with parts
                        found = True  # Set found to True as data is found

        print_info(users_file, lambda parts: print(f"ID: {parts[0]}\nName: {parts[1]}"))  # Print ID and Name
        print_info(eca_file, lambda parts: print(f"ECA Done: {parts[2]}"))  # Print ECA information
        print_info(grades_file, lambda parts: print(f"Marks: {', '.join(parts[2:])}"))  # Print Marks

        if not found:
            print("Missing info for given input")  # Print message if student data is not found
    except Exception as e:
        print("Error:", e)  # Print error message if an exception occurs

def student_menu(name, users_file, eca_file, grades_file, passwords_file):
    while True:
        try:
            print("\nStudent Menu:")
            print("(1). View ECA")
            print("(2). Show Marks")
            print("(3). Password Change")
            print("(4). Logout")
            option = int(input("Enter choice: "))

            if option == 1:
                view_student_data(name, users_file, eca_file, grades_file)  # Option to view ECA
            elif option == 2:
                view_student_data(name, users_file, eca_file, grades_file)  # Option to view mark
            elif option == 3:
                change_password(name, users_file, passwords_file)       # Option to change password
            elif option == 4:
                print("Exiting Student....")   # Option to logout
                break
            else:
                print("Invalid !! Try again.")
        except Exception as e:
            print("Error:", e)              # Print this if error occur

def change_password(name, users_file, passwords_file):
    try:
        id = input("Enter ID: ")  # Prompt user for ID
        old_pass = input("Input old password: ")  # Prompt user for old password
        new_pass = input("Input new password: ")  # Prompt user for new password

        with open(passwords_file, 'r') as file:
            lines = file.readlines()  # Read all lines from passwords file
        with open(passwords_file, 'w') as file:
            for line in lines:
                parts = line.strip().split(',')  # Split the line into parts
                if parts[0] == id and parts[1] == name and parts[2] == old_pass:
                    file.write(f"{id},{name},{new_pass}\n")  # Write new password if conditions match
                    print("Obtained New Password")  # Print success message
                else:
                    file.write(line)  # Write line back if conditions don't match
    except Exception as e:
        print("Error:", e)  # Print error message if an exception occurs

def login(users_file, eca_file, grades_file, passwords_file, is_admin=False):
    try:
        username = input("Username: ")  # Prompt user for username
        password = input("Password: ")  # Prompt user for password

        if is_admin:
            if username == "MD Faisal" and password == "123":  # Check admin credentials
                return True  # Return True if admin login successful
            else:
                return False  # Return False if admin login unsuccessful
        else:
            with open(passwords_file, 'r') as file:
                for line in file:
                    parts = line.strip().split(',')  # Split the line into parts
                    if parts[1] == username and parts[2] == password:
                        student_menu(username, users_file, eca_file, grades_file, passwords_file)
                        return True  # Return True if student login successful
            print("Try valid credentials....")  # Print message for invalid credentials
            return False  # Return False for unsuccessful login
    except Exception as e:
        print("Error:", e)  # Print error message if an exception occurs

def admin_menu(users_file, eca_file, grades_file, passwords_file):
    while True:
        try:
            print("\nAdmin Menu:")
            print("1. New Student")
            print("2. Student Data Modification")
            print("3. See Student Data")
            print("4. Logout")
            print("5. Remove Student")
            option = int(input("Enter choice: "))

            if option == 1:
                add_student(users_file, eca_file, grades_file, passwords_file)
            elif option == 2:
                modify_student(users_file, eca_file, grades_file, passwords_file)
            elif option == 3:
                name = input("Student name: ")  # Prompt user for student name
                view_student_data(name, users_file, eca_file, grades_file)  # View student data
            elif option == 4:
                print("Exiting Admin...")  # Print message for exiting admin menu
                break
            elif option == 5:
                remove_student(users_file, eca_file, grades_file, passwords_file)  # Remove student data
            else:
                print("Invalid !! Try again.")  # Print message for invalid option
        except Exception as e:
            print("Error:", e)  # Print error message if an exception occurs

def main():
    try:
        users_file = 'users.txt'  # Define users file
        eca_file = 'eca.txt'  # Define ECA file
        grades_file = 'grades.txt'  # Define grades file
        passwords_file = 'passwords.txt'  # Define passwords file
        create_files_if_not_exist(users_file, eca_file, grades_file, passwords_file)  # Create files if not exist

        while True:
            print("\nWelcome to the Login page!")
            print("Who are you?")
            print("(1). Admin")
            print("(2). Student")
            print("(3). Exit")
            option = int(input("Enter your option: "))  # Prompt user for option

            if option == 1:
                if login(users_file, eca_file, grades_file, passwords_file, is_admin=True):
                    admin_menu(users_file, eca_file, grades_file, passwords_file)  # Call admin menu for admin login
                else:
                    print("You are not the Admin !!")  # Print message for non-admin login
            elif option == 2:
                login(users_file, eca_file, grades_file, passwords_file)  # Call login for student login
            elif option == 3:
                print("Exiting....")  # Print message for exiting program
                break
            else:
                print("Sorry! You can't access")  # Print message for invalid option
    except Exception as e:
        print("Error:", e)  # Print error message if an exception occurs

        
if __name__ == '__main__':
    main()               # Execute the main function when this script is run as the main program       
