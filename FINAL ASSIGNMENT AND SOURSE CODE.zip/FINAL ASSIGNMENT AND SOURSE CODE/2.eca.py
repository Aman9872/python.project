1020,'Osama,No'
1021,'Aman,No'
